class Productos {
  String producto;
  int stock;
  String imagen;

  Productos(
      {required this.producto, required this.stock, required this.imagen});
}
