class Persona {
  String nombre;
  String? foto;

  Persona({required this.nombre, foto});
}
